export default {
  plugins: {
    '@tailwindcss/postcss': {}, // This line is the important change
    autoprefixer: {},
  },
}